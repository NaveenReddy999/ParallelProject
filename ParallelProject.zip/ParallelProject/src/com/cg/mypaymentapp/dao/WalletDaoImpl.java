package com.cg.mypaymentapp.dao;

import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;

public class WalletDaoImpl implements WalletDao{

	
Map<String, Customer> map;

	
	public WalletDaoImpl() {
		map = DataContainer.createCollection();

	}
	@Override
	public boolean save(Customer customer) {

		map.put(customer.getMobileNo(), customer);
		return true;
	}

	@Override
	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		Customer cc=map.get(mobileNo);
		return cc;
	}

}
