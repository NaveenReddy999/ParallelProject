package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.dao.WalletDao;
import com.cg.mypaymentapp.dao.WalletDaoImpl;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletServiceImpl implements WalletService {
     WalletDao dao;
     public WalletServiceImpl() {
     dao=new WalletDaoImpl();	
    }
	@Override
	public Customer createAccount(String name, String mobileno,
			BigDecimal amount) {

Wallet w= new Wallet(amount);
Customer c= new Customer(name, mobileno, w);
dao.save(c);
		return c;
	}

	@Override
	public Customer showBalance(String mobileno) throws InvalidInputException {
		
		// TODO Auto-generated method stub
		Customer c=dao.findOne(mobileno);
		if(c==null)
			throw new InvalidInputException("This Mobile Not Registered");
		return c;
	}

	

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException {
		// TODO Auto-generated method stub
	            Customer c=dao.findOne(mobileNo);
	            if(c==null){
	            	throw new InvalidInputException("Mobile Number not Registered");
	            }
	            Wallet w=c.getWallet();
	            BigDecimal curbal=w.getBalance();
	            BigDecimal newbal=curbal.add(amount);
	            w.setBalance(newbal);
	            c.setWallet(w);
	            dao.save(c);
		return c;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InvalidInputException {
		// TODO Auto-generated method stub
		Customer c=dao.findOne(mobileNo);
		if(c==null){
			throw new InvalidInputException("Enter registerd mobile Number");
		}
		else{
		Wallet w=c.getWallet();
		
		BigDecimal curbal=w.getBalance();
		if(curbal.intValue()< amount.intValue()){
			throw new InsufficientBalanceException("Balance is not Sufficient to withdraw");
		}
		BigDecimal newbal=curbal.subtract(amount);
		w.setBalance(newbal);
		c.setWallet(w);
		dao.save(c);
		return c;
		}
	}
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			BigDecimal amount) throws InvalidInputException {
		// TODO Auto-generated method stub
		Customer c=dao.findOne(sourceMobileNo);
		
		if(c==null)
		{
			throw new InvalidInputException("Sender Mobile Number Not registered"); 
		}
		else
		{
		Wallet w=c.getWallet();
		BigDecimal bal=w.getBalance();
		
		Customer c1=dao.findOne(targetMobileNo);
		if(c1==null)
		{
		throw new InvalidInputException("Beneficiary Mobile Number Not Registered");
		}
		else
		{
		Wallet w1=c1.getWallet();
		BigDecimal beneficiarybal=w1.getBalance();
        
		BigDecimal newbal=beneficiarybal.add(amount);
	
		BigDecimal newbal1=bal.subtract(amount);
		
		w1.setBalance(newbal);
        c1.setWallet(w1);
        dao.save(c1);
		
        w.setBalance(newbal1);
        c.setWallet(w);
        
		return c;
		}
		}
		}
	@Override
	public boolean Validatename(String name) {
		
		Pattern p=Pattern.compile("[A-Z][A-Za-z ]{3,20}");
		Matcher m=p.matcher(name);
		return m.matches();
	}
	@Override
	public boolean ValidateMobileNo(String mobno) {
		// TODO Auto-generated method stub
		Pattern p=Pattern.compile("[6789][0-9]{9}");
		Matcher m=p.matcher(mobno);
		return m.matches();
	}
	@Override
	public boolean validateAmount(BigDecimal amount) {
		// TODO Auto-generated method stub
		Pattern p=Pattern.compile("[1-9][0-9]{2,5}");
		Matcher m=p.matcher(String.valueOf(amount));
		return m.matches();
	}

}
