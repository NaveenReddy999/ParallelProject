package com.cg.mypaymentapp.ui;

import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Main {
	public static void main(String[] args) throws InvalidInputException{
		
		
		WalletService service= new WalletServiceImpl();
		Scanner sc=new Scanner(System.in);
		int ch=0;
		do{
			System.out.println("Enter your choice");
			System.out.println("1: Create Account");
			System.out.println("2: Show Balance");
			System.out.println("3: Deposit");
			System.out.println("4: Withdraw");
			System.out.println("5: Fund Transfer");
			System.out.println("6: Print Transactions");
			
			ch=sc.nextInt();
			switch(ch){
			case 1:
				System.out.println("Enter Customer Name");
                   String name= sc.next();
                   if(service.Validatename(name)){
                   System.out.println("Enter Mobile Number");
                   String phn=sc.next();
                     if(service.ValidateMobileNo(phn)){
                     System.out.println("Enter Balance");
                     BigDecimal dec=sc.nextBigDecimal();
                         if(service.validateAmount(dec)){
                         Customer cust=service.createAccount(name, phn, dec);
                         System.out.println(cust);
                         } 
                         else
                        	 System.out.println("Amount must be greater than 100 and less than 100000");
                   }
                   else
                	   System.out.println("Enter Correct Mobile Number");
                   }
                   else
                	   System.out.println("Please Enter the Correct Name");
			break;
			case 2:
				Customer cust1;
			  System.out.println("Enter Mobile Number");
			  String mobno=sc.next();
			  if(service.ValidateMobileNo(mobno)){
			
			try {
				
				cust1 = service.showBalance(mobno);
				System.out.println(cust1);
			} catch (InvalidInputException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		
			
			  }
			  else
				  System.out.println("Enter correct Mobile Number");
			break;
			
			case 3:
				System.out.println("Enter Mobile Number");
				String mobno1=sc.next();
				if(service.ValidateMobileNo(mobno1)){
				System.out.println("Enter the Amount to deposit");
				BigDecimal dec1=sc.nextBigDecimal();
				if(service.validateAmount(dec1)){
				Customer deposit;
				try {
					deposit = service.depositAmount(mobno1, dec1);
					System.out.println(deposit);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				}
				else
					System.out.println("Enter the correct Amount");
				}
				else
					System.out.println("Enter Correct Number");
				break;
				
			case 4:
				
				System.out.println("Enter mobile Number");
				String mobno2=sc.next();
				if(service.ValidateMobileNo(mobno2)){
				  System.out.println("Enter the Amount to Withdraw");
				  BigDecimal dec2=sc.nextBigDecimal();
				    if(service.validateAmount(dec2)){
				     Customer withdraw ;
					try {
						withdraw = service.withdrawAmount(mobno2, dec2);
						 System.out.println(withdraw);
					} catch (InvalidInputException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					catch(InsufficientBalanceException e){
						System.out.println(e.getMessage());
					}
				    
				
				    }
				    else 
				    	System.out.println("Enter Correct Amount");
				}
				else
					System.out.println("Enter correct Mobile Number");
				break;
			case 5:
				System.out.println("Enter your Mobile Number");
				String mobno3=sc.next();
				if(service.ValidateMobileNo(mobno3)){
				System.out.println("Enter the beneficiary number");
				String bennum=sc.next();
				if(service.ValidateMobileNo(bennum)){
				System.out.println("Enter the amount you want to Tranfer");
				BigDecimal fund=sc.nextBigDecimal();
				if(service.validateAmount(fund)){
				Customer fundtransfer ;
				try {
					fundtransfer = service.fundTransfer(mobno3, bennum, fund);
					System.out.println(fundtransfer);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				}
				else
					System.out.println("Enter Correct Amount");
				}
				else 
					System.out.println("Enter Correct Number");
				}
				else
					System.out.println("Enter Correct Mobile Number");
				break;
			case 6:
				System.out.println("your transactions are");
				
				
			case 7:
				System.out.println("You pressed the Exit Button");
			}
		}while(ch!=8);
		
		
	}
	
}